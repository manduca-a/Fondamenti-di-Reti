iptables -F
iptables -X

iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

iptables -N greenAll
iptables -N allGreen

iptables -A FORWARD -s 10.0.0.0/22 -i eth1 -o eth0 -j greenAll
iptables -A FORWARD -d 10.0.0.0/22 -i eht0 -o eth1 -j allGreen

iptables -A greenAll -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
iptables -A allGreen -m state --state ESTABLISHED,RELATED -j ACCEPT

# SSH
iptables -A INPUT -p tcp -i eth0 --dport 22 -j ACCEPT
iptables -A OUTPUT -p tcp -o eth0 --sport 22 -m state --state 	ESTALBLISHED,RELATED -j ACCEPT

#Portforwarding
iptables -t nat -A PREROUTING -i eth1 -p tcp --dport 80 -j DNAT --to-destination 10.0.6.2
iptables -t nat -A POSTROUTING -p tcp --sport 80 -j SNAT --to-source 10.0.6.2
iptables -t nat -A PREROUTING -i eth1 -p tcp --dport 22 -j DNAT --to-destination 10.0.6.130:22
iptables -t nat -A PREROUTING -i eth1 -p udp --dport 53 -j DNAT --to-destination 10.0.6.131:53
iptables -t nat -A PREROUTING -i eth1 -p tcp --dport 25 -j DNAT --to-destination 10.0.6.4:25
iptables -t nat -A PREROUTING -i eth1 -p tcp --dport 21 -j DNAT --to-destination 10.0.6.3:21
