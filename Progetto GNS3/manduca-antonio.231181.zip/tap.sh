#!/bin/bash
tunctl -g netdev -t tap0  #Creazione interfaccia

ifconfig tap0 10.0.7.13
ifconfig tap0 netmask 255.255.255.252
ifconfig tap0 broadcast 10.0.7.15
ifconfig tap0 up

iptables -t nat -F
iptables -t nat -X

iptables -F
iptables -X

iptables -t nat -A POSTROUTING -o wlp4s0 -j MASQUERADE #natting
iptables -A FORWARD -i tap0 -j ACCEPT

route add -net 10.0.0.0/8 gw 10.0.7.14 dev tap0 #rotta verso la rete 10.0.0.0

sysctl -w net.ipv4.ip_forward=1  #forwarding su host locale
