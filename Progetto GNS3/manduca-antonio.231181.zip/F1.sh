#!/bin/sh

# Flush ed Eliminazione vecchie catene
iptables -F	#Flush
iptables -X	#Cancella vecchie catene

# Policy di Default
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

# Sottocatene
iptables -N DMZRED
iptables -N REDDMZ
iptables -N greenAll
iptables -N allGreen

# Collegamento a catene di default
iptables -A FORWARD -s 10.0.6.0/24 -d 10.0.4.0/23 -i eth1 -o eth0 -j DMZRED
iptables -A FORWARD -s 10.0.4.0/23 -d 10.0.6.0/24 -i eth0 -o eth1 -j REDDMZ
iptables -A FORWARD -s 10.0.0.0/22 -i eth1 -j greenAll		#connessioni che arrivano da green
iptables -A FORWARD -d 10.0.0.0/22 -o eth1 -j allGreen		#connessioni che vanno verso green

# Regole sottocatene
iptables -A DMZRED -j ACCEPT
iptables -A REDDMZ -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A greenAll -j ACCEPT		#qualsiasi connessione da green va bene
iptables -A allGreen -m state --state ESTABLISHED,RELATED -j ACCEPT	#risponde solo se già stabilita

# Connessione ssh
iptables -A INPUT -i eth2 -p tcp --dport 22 -j ACCEPT
iptables -A OUTPUT -o eth2 -p tcp --sport 22 -m state --state ESTABLISHED,RELATED -j ACCEPT

# SSH per F2
iptables -A FORWARD -p tcp --dport 22 -i eth2 -o eth1 -d 10.0.7.6 -j ACCEPT
iptables -A FORWARD -p tcp --sport 22 -i eth1 -o eth2 -s 10.0.7.6 -m state --state 	ESTALBLISHED,RELATED -j ACCEPT

#Portforwarding porta 80 su 10.0.6.2
iptables -t nat -A PREROUTING -i eth2 -p tcp --dport 80 -j DNAT --to-destination 10.0.6.2
iptables -t nat -A POSTROUTING -p tcp --sport 80 -j SNAT --to-source 10.0.6.2 # fa in modo che i pacchetti in risposta abbiano ip del server

#Porta 22 su 10.0.6.130
iptables -t nat -A PREROUTING -p tcp --dport 22 -j DNAT --to-destination 10.0.6.130:22

# Porta 53 su 10.0.6.131
iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to-destination 10.0.6.131:53

# Porta 25 su 10.0.6.4
iptables -t nat -A PREROUTING -p tcp --dport 25 -j DNAT --to-destination 10.0.6.4:25

# Porta 21 su 10.0.6.3
iptables -t nat -A PREROUTING -p tcp --dport 21 -j DNAT --to-destination 10.0.6.3:21
